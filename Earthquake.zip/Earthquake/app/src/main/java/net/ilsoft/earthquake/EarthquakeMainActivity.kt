package net.ilsoft.earthquake

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.ProcessLifecycleOwner
import java.util.Calendar

class EarthquakeMainActivity : AppCompatActivity() {
    private val TAG_LIST_FRAGMENT: String = "TAG_LIST_FRAGMENT"
    private lateinit var earthquakeListFragment: EarthquakeListFragment
    private val earthquakeViewModel: EarthquakeViewModel by viewModels { EarthquakeViewModel.Factory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_earthquake_main)
        val fm = supportFragmentManager

        if (savedInstanceState == null) {
            val ft = fm.beginTransaction()
            earthquakeListFragment = EarthquakeListFragment(earthquakeViewModel) {
                earthquakeViewModel.loadEarthquake()
            }
            ft.add(R.id.main_activity_frame, earthquakeListFragment, TAG_LIST_FRAGMENT)
            ft.commitNow()
            Log.d("프레그먼트-메인", "프레그먼트 실행")
        } else {
            earthquakeListFragment =
                fm.findFragmentByTag(TAG_LIST_FRAGMENT) as EarthquakeListFragment
        }
        ProcessLifecycleOwner.get().lifecycle.addObserver(earthquakeListFragment)
    }
}