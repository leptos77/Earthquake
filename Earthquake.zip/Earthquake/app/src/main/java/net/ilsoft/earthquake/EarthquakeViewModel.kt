package net.ilsoft.earthquake

import android.app.Application
import android.location.Location
import android.os.Looper
import android.util.Log
import androidx.lifecycle.*
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import org.w3c.dom.Element
import org.w3c.dom.NodeList
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLConnection
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import java.util.logging.Handler
import javax.xml.parsers.DocumentBuilderFactory

class EarthquakeViewModel(val application: Application) : ViewModel() {
    private val TAG = "프레그먼트2"
    val handler = android.os.Handler(Looper.getMainLooper())

    var earthquakes: MutableLiveData<List<Earthquake>> = MutableLiveData()
        get() {
            Log.d(TAG, "라이브데이터")
            return field
        }


    fun loadEarthquake() {
        Thread {
            Log.d(TAG, "Thread Start")
            val Iearthquakes = mutableListOf<Earthquake>()
            try {
                val quakeFeed = application.getString(R.string.earthquake_feed)
                val connection = URL(quakeFeed).openConnection() as HttpURLConnection
                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val input = connection.inputStream
                    val db = DocumentBuilderFactory.newInstance().newDocumentBuilder()

                    val dom = db.parse(input)
                    val docEle = dom.documentElement

                    // 각 지진 항목의 내역을 가져온다.
                    val nl: NodeList? = docEle.getElementsByTagName("entry")
                    if (nl != null && nl.length > 0) {
                        for (i in 0 until nl.length) {
                            val entry = nl.item(i) as Element
                            val id = entry.getElementsByTagName("id").item(0) as Element
                            val title = entry.getElementsByTagName("title").item(0) as Element
                            val g = entry.getElementsByTagName("georss:point").item(0) as Element
                            val `when` = entry.getElementsByTagName("updated").item(0) as Element
                            val link = entry.getElementsByTagName("link").item(0) as Element

                            val idString = id.firstChild.nodeValue
                            var details = title.firstChild.nodeValue
                            val hostname = "http://earthquake.usgs.gov"
                            val linkString = hostname + link.getAttribute("href")
                            val point = g.firstChild.nodeValue
                            val dt = `when`.firstChild.nodeValue
                            val sdf = SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSS'Z'")
                            var qdate = GregorianCalendar(0, 0, 0).time
                            try {
                                qdate = sdf.parse(dt) as Date
                            } catch (e: ParseException) {
                                Log.e(TAG, "Date parsing exception.", e)
                            }

                            val location = point.split(" ")
                            val l = Location("dummyGPS")
                            l.latitude = location[0].toDouble()
                            l.longitude = location[1].toDouble()

                            val magnitudeString = details.split(" ")[1]
                            val end = magnitudeString.length - 1
                            val magnitude = magnitudeString.substring(0, end).toDouble()
                            details =
                                if (details.contains("-")) details.split("-")[1].trim() else ""
                            Iearthquakes.add(
                                Earthquake(idString, qdate, details, l, magnitude, linkString)
                            )
                        }
                    }
                }
                connection.disconnect()
            } catch (e: Exception) {
                Log.e(TAG, e.stackTraceToString())
            }
            handler.post {
                Log.d(TAG, "${Iearthquakes[0].toString()}")
                earthquakes.value = Iearthquakes
            }
        }.start()
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(
                modelClass: Class<T>,
                extras: CreationExtras
            ): T {
                // Get the Application object from extras
                val application = checkNotNull(extras[APPLICATION_KEY])
                // Create a SavedStateHandle for this ViewModel from extras
                val savedStateHandle = extras.createSavedStateHandle()

                return EarthquakeViewModel(application) as T
            }
        }
    }
}