package net.ilsoft.earthquake

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PreferencesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.preferences)
    }

    class PrefFragment:PreferenceFragmentCompat(){

    }
}